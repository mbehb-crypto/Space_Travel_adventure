""" """

import random
import time
import sys
import winsound  # Built-in Windows sound library


def play_alert(freq, duration):
    """Plays a simple beep sound."""
    winsound.Beep(freq, duration)


def get_user_input(player_name, limit):
    data = {}
    print(f"\n🚀 {player_name.upper()}'S TURN | Limit: {limit}s")

    start_time = time.time()
    prompts = [
        ('name', "Hero Name: "), ('planet', "Planet: "),
        ('adj', "Adjective: "), ('noun', "Noun: "), ('verb', "Verb (-ing): ")
    ]

    for key, prompt in prompts:
        data[key] = input(prompt)
        elapsed = time.time() - start_time

        # Audio warning if more than 70% of time has passed
        if elapsed > (limit * 0.7):
            play_alert(500, 100)  # Low warning beep

        if elapsed > limit:
            play_alert(200, 500)  # Deep 'fail' sound
            print(f"\n💥 MISSION FAILED! Time's up.")
            return None

    data['duration'] = round(time.time() - start_time, 2)
    play_alert(1500, 300)  # High-pitched success chime
    return data


def main():
    print("--- 🌌 MULTIPLAYER SPACE RACE 🌌 ---")
    p1 = input("Player 1: ")
    p2 = input("Player 2: ")

    res1 = get_user_input(p1, 20)
    res2 = get_user_input(p2, 20)

    # Winner logic
    if res1 and res2:
        winner = p1 if res1['duration'] < res2['duration'] else p2
        print(f"\n🏆 CHAMPION: {winner.upper()}!")
        # Victory fanfare!
        for f in [1000, 1200, 1500]: play_alert(f, 150)


if __name__ == "__main__":
    main()